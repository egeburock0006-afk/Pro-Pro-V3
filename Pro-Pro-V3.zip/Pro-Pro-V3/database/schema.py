from database.database import engine
from database.models import Base
from database.tables.last_signals import LastSignal
# Tablolar
from database.tables.settings import Settings


def create_database():
    Base.metadata.create_all(bind=engine)
    
