from sqlalchemy import Boolean
from sqlalchemy import Integer

from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column

from database.models import Base


class Settings(Base):

    __tablename__ = "settings"

    id: Mapped[int] = mapped_column(primary_key=True)

    ai_threshold: Mapped[int] = mapped_column(Integer)

    watchlist_threshold: Mapped[int] = mapped_column(Integer)

    scan_interval: Mapped[int] = mapped_column(Integer)

    notification: Mapped[bool] = mapped_column(Boolean)

    triple_confirmation: Mapped[bool] = mapped_column(Boolean)