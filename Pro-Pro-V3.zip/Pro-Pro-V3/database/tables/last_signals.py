from sqlalchemy import String

from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column

from database.models import Base


class LastSignal(Base):

    __tablename__ = "last_signals"

    symbol: Mapped[str] = mapped_column(
        String,
        primary_key=True
    )

    signal: Mapped[str] = mapped_column(String)