import sqlite3
from config import TRADE_MARGIN, LEVERAGE
DB = "database/bot.db"
from datetime import datetime

from core.test_engine import get_position_size


def has_open_trade(symbol):

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
        SELECT COUNT(*)
        FROM trades
        WHERE symbol=?
        AND status='OPEN'
    """, (symbol,))

    count = cur.fetchone()[0]

    print(f"CHECK => {symbol}  OPEN={count}")   # <-- EKLE

    conn.close()

    return count > 0




def save_trade(symbol, signal, entry, tp1, tp2, tp3, stop):

    margin = get_position_size()
    
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    open_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS trades(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        symbol TEXT,

        signal TEXT,

        entry REAL,

        tp1 REAL,

        tp2 REAL,

        tp3 REAL,

        stop REAL,
        
        margin REAL,
        
        leverage INTEGER,

        open_time TEXT,
        
        close_time TEXT,

        result TEXT,
        
        roi REAL,
        
        profit REAL,       
        
        status TEXT,
        
        tp1_hit INTEGER DEFAULT 0,

        tp2_hit INTEGER DEFAULT 0,
        
        tp3_hit INTEGER DEFAULT 0,
        stop_hit INTEGER DEFAULT 0
    )
    """)

    cur.execute("""
       
    INSERT INTO trades(

        symbol,
        signal,
        entry,
        tp1,
        tp2,
        tp3,
        stop,
        margin,
        leverage,
        open_time,
        status

    )

    VALUES(?,?,?,?,?,?,?,?,?,?,?)

    """, (

        symbol,
        signal,
        entry,
        tp1,
        tp2,
        tp3,
        stop,
        margin,
        LEVERAGE,
        open_time,
        "OPEN"

    ))

    conn.commit()
    conn.close()


def get_open_trades():

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    SELECT
        id,
        symbol,
        signal,
        entry,
        tp1,
        tp2,
        tp3,
        stop,
        margin,
        leverage,
        tp1_hit,
        tp2_hit,
        tp3_hit,
        stop_hit

    FROM trades

    WHERE status='OPEN'

    """)

    rows = cur.fetchall()

    print(rows)

    conn.close()
       
    return rows

from datetime import datetime
def close_trade(trade_id, result,roi, profit):

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    close_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cur.execute("""

    UPDATE trades

    SET

        status='CLOSED',

        close_time=?,

        result=?,
        
        roi=?,
        
        profit=?

    WHERE id=?

    """, (

        close_time,

        result,
        
        roi,
        
        profit,

        trade_id

    ))

    conn.commit()

    conn.close()
    
def update_trade_status(trade_id, status):

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    UPDATE trades

    SET status=?

    WHERE id=?

    """, (

        status,
        trade_id

    ))

    conn.commit()

    conn.close()

    
def mark_tp1(trade_id):

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""

    UPDATE trades

    SET tp1_hit=1

    WHERE id=?

    """, (trade_id,))

    conn.commit()
    conn.close()


def mark_tp2(trade_id):

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""

    UPDATE trades

    SET tp2_hit=1

    WHERE id=?

    """, (trade_id,))

    conn.commit()
    conn.close()    
    
def get_trades_by_status(status):

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    SELECT *

    FROM trades

    WHERE status=?

    """, (

        status,

    ))

    rows = cur.fetchall()

    conn.close()

    return rows   

def mark_tp3(trade_id):

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    UPDATE trades

    SET tp3_hit=1

    WHERE id=?

    """, (trade_id,))

    conn.commit()

    conn.close()
    
def mark_stop(trade_id):

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    UPDATE trades

    SET stop_hit=1

    WHERE id=?

    """, (trade_id,))

    conn.commit()

    conn.close()   
    
def get_tp1_count():

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
        SELECT COUNT(*)
        FROM trades
        WHERE tp1_hit=1
    """)

    count = cur.fetchone()[0]

    conn.close()

    return count

def get_tp2_count():

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
        SELECT COUNT(*)
        FROM trades
        WHERE tp2_hit=1
    """)

    count = cur.fetchone()[0]

    conn.close()

    return count

def get_tp3_count():

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
        SELECT COUNT(*)
        FROM trades
        WHERE tp3_hit=1
    """)

    count = cur.fetchone()[0]

    conn.close()

    return count

def get_stop_count():

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
        SELECT COUNT(*)
        FROM trades
        WHERE stop_hit=1
    """)

    count = cur.fetchone()[0]

    conn.close()

    return count

def get_trade_by_id(trade_id):

    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    cur.execute("""
        SELECT
            id,
            symbol,
            signal,
            entry,
            tp1,
            tp2,
            tp3,
            stop,
            margin,
            leverage,
            tp1_hit,
            tp2_hit,
            tp3_hit,
            stop_hit
        FROM trades
        WHERE id = ?
    """, (trade_id,))

    trade = cur.fetchone()

    conn.close()

    return trade


  