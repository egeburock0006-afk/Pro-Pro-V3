from database.database import SessionLocal
from database.tables.last_signals import LastSignal


def get_last_signal(symbol):

    db = SessionLocal()

    row = (
        db.query(LastSignal)
        .filter(
            LastSignal.symbol == symbol
        )
        .first()
    )

    db.close()

    if row:
        return row.signal

    return None


def save_signal(symbol, signal):

    db = SessionLocal()

    row = (
        db.query(LastSignal)
        .filter(
            LastSignal.symbol == symbol
        )
        .first()
    )

    if row:

        row.signal = signal

    else:

        db.add(
            LastSignal(
                symbol=symbol,
                signal=signal
            )
        )

    db.commit()
    db.close()