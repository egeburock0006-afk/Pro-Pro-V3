import sqlite3

DB = "database/bot.db"


def create_wallet():

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    CREATE TABLE IF NOT EXISTS wallet(

        id INTEGER PRIMARY KEY,

        balance REAL

    )

    """)

    cur.execute("""

    INSERT OR IGNORE INTO wallet(

        id,

        balance

    )

    VALUES(

        1,

        100

    )

    """)

    conn.commit()

    conn.close()
def get_wallet():

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    SELECT balance

    FROM wallet

    WHERE id=1

    """)

    balance = cur.fetchone()[0]

    conn.close()

    return balance


def update_wallet(balance):

    conn = sqlite3.connect(DB)

    cur = conn.cursor()

    cur.execute("""

    UPDATE wallet

    SET balance=?

    WHERE id=1

    """, (balance,))

    conn.commit()

    conn.close()