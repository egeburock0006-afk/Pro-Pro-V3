def calculate_ai_score(result, ema200, price, mfi, macd, adx):

    score = 0

    # AlphaTrend yönü
    if result["direction"] == 1:
        score += 20

    # EMA Trendi
    if price > ema200:
        score += 20

    # MFI
    if 50 <= mfi <= 80:
        score += 20

    # MACD
    if macd > 0:
        score += 20

    # Strength
    strength = result["strength"]    

    if strength >= 70:
        score += 20
    elif strength >= 50:
        score += 15
    elif strength >= 30:
        score += 10
    elif strength >= 10:
        score += 5
        
    # ADX
    if adx >= 35:
        score += 20
    elif adx >= 25:
        score += 15
    elif adx >= 20:
        score += 10
    elif adx >= 15:
        score += 5

    return min(score, 100)