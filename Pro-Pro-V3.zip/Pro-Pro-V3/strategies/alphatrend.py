import pandas as pd
import numpy as np

from utils.mfi import mfi


class AlphaTrend:

    def __init__(self, length=14, multiplier=1.0):

        self.length = length
        self.multiplier = multiplier

    def calculate(self, df):

        data = df.copy()

        # ==========================
        # TRUE RANGE
        # ==========================

        high_low = data["high"] - data["low"]

        high_close = (
            data["high"] -
            data["close"].shift(1)
        ).abs()

        low_close = (
            data["low"] -
            data["close"].shift(1)
        ).abs()

        data["TR"] = pd.concat(

            [

                high_low,

                high_close,

                low_close

            ],

            axis=1

        ).max(axis=1)

        # ==========================
        # Pine:
        # ATR = ta.sma(ta.tr, AP)
        # ==========================

        data["ATR"] = (

            data["TR"]

            .rolling(self.length)

            .mean()

        )

        # ==========================
        # Pine:
        # ta.mfi(hlc3, AP)
        # ==========================

        data["MFI"] = mfi(

            data,

            self.length

        )

        # ==========================

        data["upT"] = (

            data["low"]

            -

            data["ATR"]

            *

            self.multiplier

        )

        data["downT"] = (

            data["high"]

            +

            data["ATR"]

            *

            self.multiplier

        )

        # ==========================
        # AlphaTrend
        # ==========================

        alpha = np.zeros(len(data))

        for i in range(1, len(data)):

            prev = alpha[i - 1]

            if data["MFI"].iloc[i] >= 50:

                if data["upT"].iloc[i] < prev:

                    alpha[i] = prev

                else:

                    alpha[i] = data["upT"].iloc[i]

            else:

                if data["downT"].iloc[i] > prev:

                    alpha[i] = prev

                else:

                    alpha[i] = data["downT"].iloc[i]

        data["AlphaTrend"] = alpha

        # ==========================

        data["Trigger"] = data["AlphaTrend"].shift(2)
                # ==========================
        # Pine:
        # ta.crossover()
        # ta.crossunder()
        # ==========================

        data["buySignal"] = (

            (data["AlphaTrend"] > data["Trigger"])

            &

            (data["AlphaTrend"].shift(1) <= data["Trigger"].shift(1))

        )

        data["sellSignal"] = (

            (data["AlphaTrend"] < data["Trigger"])

            &

            (data["AlphaTrend"].shift(1) >= data["Trigger"].shift(1))

        )

        # ==========================
        # Pine:
        # ta.barssince()
        # ==========================

        buyBars = []
        sellBars = []

        lastBuy = -99999
        lastSell = -99999

        for i in range(len(data)):

            if data["buySignal"].iloc[i]:

                lastBuy = i

            if data["sellSignal"].iloc[i]:

                lastSell = i

            buyBars.append(i - lastBuy)

            sellBars.append(i - lastSell)

        data["K1"] = buyBars
        data["K2"] = sellBars

        data["O1"] = data["K1"].shift(1)
        data["O2"] = data["K2"].shift(1)

        # ==========================
        # Pine:
        # direction
        # ==========================

        direction = []

        lastDirection = 0

        for i in range(len(data)):

            buy = (

                data["buySignal"].iloc[i]

                and

                data["O1"].iloc[i] > data["K2"].iloc[i]

            )

            sell = (

                data["sellSignal"].iloc[i]

                and

                data["O2"].iloc[i] > data["K1"].iloc[i]

            )

            if buy:

                lastDirection = 1

            elif sell:

                lastDirection = -1

            direction.append(lastDirection)

        data["direction"] = direction

        data["buy"] = (

            data["buySignal"]

            &

            (data["O1"] > data["K2"])

        )

        data["sell"] = (

            data["sellSignal"]

            &

            (data["O2"] > data["K1"])

        )

        return data
    
    
    def last_signal(self, df):

        data = self.calculate(df)

        last = data.iloc[-1]

        signal = None

        if last["buy"]:
            signal = "BUY"

        elif last["sell"]:
            signal = "SELL"

        strength = abs(last["MFI"] - 50) * 2

        return {

            "name": "AlphaTrend",

            "signal": signal,

            "direction": int(last["direction"]),

            "price": float(last["close"]),

            "strength": float(round(strength, 1)),

            "alphatrend": float(last["AlphaTrend"]),

            "atr": float(last["ATR"]),

            "mfi": float(last["MFI"])

        }