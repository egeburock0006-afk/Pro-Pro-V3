import pandas as pd


class FollowLine:

    def __init__(self,
                 atr_period=14,
                 atr_multiplier=1):

        self.atr_period = atr_period
        self.atr_multiplier = atr_multiplier

    def calculate(self, df: pd.DataFrame):

        data = df.copy()

        return data