from dotenv import load_dotenv
import os

load_dotenv()

# Binance
BINANCE_API_KEY = os.getenv("BINANCE_API_KEY")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET")

# Telegram
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# Scanner
INTERVAL = "15m"
TRADE_MARGIN = 10
LEVERAGE = 10
LIMIT = 300
SCAN_DELAY = 60

# AI
AI_THRESHOLD = 70

# Watchlist
WATCHLIST_THRESHOLD = 50

# Database
DATABASE = "database/bot.db"