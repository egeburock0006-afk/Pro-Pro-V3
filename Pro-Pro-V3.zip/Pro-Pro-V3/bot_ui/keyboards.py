from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def dashboard_keyboard():

    keyboard = [

        [
            InlineKeyboardButton(
                "📊 Dashboard",
                callback_data="dashboard",
            )
        ],

        [
            InlineKeyboardButton(
                "💰 Wallet",
                callback_data="wallet",
            )
        ],

        [
            InlineKeyboardButton(
                "📈 Açık İşlemler",
                callback_data="trades",
            )
        ],

        [
            InlineKeyboardButton(
                "👀 Watchlist",
                callback_data="watchlist",
            )
        ],

        [
            InlineKeyboardButton(
                "🏆 AI Ranking",
                callback_data="ranking",
            )
        ],

        [
            InlineKeyboardButton(
                "📋 Son Sinyaller",
                callback_data="signals",
            )
        ],

        [
            InlineKeyboardButton(
                "⚙️ Ayarlar",
                callback_data="settings",
            )
        ]

    ]

    return InlineKeyboardMarkup(keyboard)


def back_keyboard():

    keyboard = [

        [
            InlineKeyboardButton(
                "⬅️ Ana Menü",
                callback_data="home"
            )
        ]

    ]

    return InlineKeyboardMarkup(keyboard)


def main_menu():
    return dashboard_keyboard()