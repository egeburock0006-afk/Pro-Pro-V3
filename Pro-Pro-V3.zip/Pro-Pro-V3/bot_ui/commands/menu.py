from bot_ui.menus.trades import trades_menu



from bot_ui.menus.dashboard_live import dashboard_live
from bot_ui.menus.wallet import wallet_menu

async def menu_handler(update, context):

    text = update.message.text

    if text == "📊 Dashboard":

        dashboard, keyboard = dashboard_live()

        await update.message.reply_text(

            dashboard,

            reply_markup=keyboard

        )
    elif text == "💰 Wallet":

        wallet, keyboard = wallet_menu()

        await update.message.reply_text(

        wallet,

        reply_markup=keyboard

        )
        
    elif text == "📈 Trades":

        trades, keyboard = trades_menu()
        
        print(type(keyboard))
        print(keyboard)
        
        

        await update.message.reply_text(

        trades,

        reply_markup=keyboard

    )