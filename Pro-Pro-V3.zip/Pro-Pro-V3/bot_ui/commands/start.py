from bot_ui.keyboards import dashboard_keyboard
from bot_ui.reply_keyboard import main_reply_keyboard

async def start(update, context):

    print("START KOMUTU ÇALIŞTI")

    await update.message.reply_text(

        "🤖 FollowLine Pro AI V4\n\n"
        "Hoş geldin kanka 👋\n\n"
        "Aşağıdaki menüyü kullanarak botu yönetebilirsin.",

        reply_markup=main_reply_keyboard()

    )