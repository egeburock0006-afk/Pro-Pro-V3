from telegram import ReplyKeyboardMarkup


def main_reply_keyboard():

    keyboard = [

        ["📊 Dashboard", "💰 Wallet"],

        ["📈 Trades", "👀 Watchlist"],

        ["🏆 Ranking", "⚙️ Settings"]

    ]

    return ReplyKeyboardMarkup(

        keyboard,

        resize_keyboard=True,

        is_persistent=True

    )