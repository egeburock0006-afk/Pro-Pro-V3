

from telegram.ext import CommandHandler
from telegram.ext import CallbackQueryHandler

from bot_ui.commands.start import start
from bot_ui.callbacks import callbacks
from telegram.ext import CallbackQueryHandler


def register_handlers(application):

    print("Handlers registered")
    
    
    application.add_handler(
        CommandHandler("start", start)
    )
    from telegram.ext import MessageHandler, filters
    from bot_ui.commands.menu import menu_handler
       
    application.add_handler(

        MessageHandler(

            filters.TEXT & ~filters.COMMAND,

            menu_handler

            )

        )    
    
    
    application.add_handler(
        CallbackQueryHandler(callbacks)
    )
   