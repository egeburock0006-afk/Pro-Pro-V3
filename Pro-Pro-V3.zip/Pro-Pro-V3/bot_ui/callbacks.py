from telegram import Update
from telegram.ext import ContextTypes
from database.trade_db import get_trade_by_id
from bot_ui.menus.dashboard import dashboard_text, dashboard_keyboard
from bot_ui.menus.dashboard_live import dashboard_live
from services.binance_service import get_current_price

async def callbacks(update: Update, context: ContextTypes.DEFAULT_TYPE):

    query = update.callback_query
    await query.answer()

    print("CALLBACK:", query.data)

    if query.data.startswith("trade_"):

        trade_id = int(query.data.replace("trade_", ""))
        
        trade = get_trade_by_id(trade_id)
        
        
        if trade is None:

            await query.edit_message_text(
                "❌ İşlem bulunamadı."
            )
            return
        
    (
        trade_id,
        symbol,
        signal,
        entry,
        tp1,
        tp2,
        tp3,
        stop,
        margin,
        leverage,
        tp1_hit,
        tp2_hit,
        tp3_hit,
        stop_hit,
    ) = trade
    
    
    current_price = get_current_price(symbol)
    
    direction = "LONG" if signal == "BUY" else "SHORT"
    emoji = "🟢" if signal == "BUY" else "🔴"

    await query.edit_message_text(
        text=
            f"{emoji} {symbol}\n\n"
            f"{direction}\n\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            f"💰 Entry\n{entry}\n"
            f"📈 Current\n{current_price}\n"
        )
    
    
    
    
    
    

    if query.data == "home":

        await query.edit_message_text(
            text=dashboard_text(),
            reply_markup=dashboard_keyboard(),
            parse_mode="HTML"
        )
        return

    if query.data == "dashboard":

        text, keyboard = dashboard_live()

        await query.edit_message_text(
            text=text,
            reply_markup=keyboard
        )
        return