from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def trades_keyboard(trades):

    keyboard = []

    for trade in trades:

        trade_id = trade[0]
        symbol = trade[1]
        signal = trade[2]

        emoji = "🟢" if signal == "BUY" else "🔴"
        direction = "LONG" if signal == "BUY" else "SHORT"

        keyboard.append([
            InlineKeyboardButton(
                f"{emoji} {symbol}  {direction}",
                callback_data=f"trade_{trade_id}"
            )
        ])

    keyboard.append([
        InlineKeyboardButton(
            "⬅️ Ana Menü",
            callback_data="home"
        )
    ])

    return InlineKeyboardMarkup(keyboard)