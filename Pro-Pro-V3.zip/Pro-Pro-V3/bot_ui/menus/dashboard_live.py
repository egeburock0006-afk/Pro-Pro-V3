from core.dashboard import build_dashboard

from bot_ui.keyboards import back_keyboard


def dashboard_live():

    return (

        build_dashboard(),

        back_keyboard()

    )