from bot_ui.keyboards import back_keyboard
from services.status_service import get_status

def status_menu():
    status = get_status()
    telegram = "🟢 Online" if status["telegram"] else "🔴 Offline"

    binance = "🟢 Hazır" if status["binance"] else "🔴 Bağlı Değil"

    scanner = "🟢 Çalışıyor" if status["scanner"] else "🟡 Bekliyor"

    database = "🟢 Hazır" if status["database"] else "🔴 Hata"

    cpu = status["cpu"]

    ram = status["ram"]

    uptime = status["uptime"]
    text = f"""
📊 BOT DURUMU

━━━━━━━━━━━━━━━━━━

🤖 Telegram : {telegram}

📡 Binance : {binance}

📊 Scanner : {scanner}

💾 Database : {database}

━━━━━━━━━━━━━━━━━━

💻 CPU : {cpu}

🧠 RAM : {ram}

⏱ Uptime : {uptime}
"""

    return text, back_keyboard()