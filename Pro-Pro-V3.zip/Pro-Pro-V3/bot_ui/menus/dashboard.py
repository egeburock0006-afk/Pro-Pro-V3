from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from bot_ui.keyboards import dashboard_keyboard

def dashboard_text():
    return """
🤖 <b>FollowLine Pro AI V3</b>

━━━━━━━━━━━━━━━━━━━━━━

🟢 <b>Bot Durumu</b> : ONLINE

📡 Binance : 🟢

🤖 AI Engine : 🟢

📊 Scanner : 🟢

💾 Database : 🟢

━━━━━━━━━━━━━━━━━━━━━━

📈 Açık İşlem : 0

👀 Watchlist : 0

🏆 Triple Confirm : 0

━━━━━━━━━━━━━━━━━━━━━━

Version : V3.0.0
"""
