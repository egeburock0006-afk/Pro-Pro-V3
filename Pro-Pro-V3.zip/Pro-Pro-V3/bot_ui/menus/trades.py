from bot_ui.keyboards import back_keyboard
from database.trade_db import get_open_trades

from services.binance_service import get_current_price
from core.progress_bar import build_progress
from bot_ui.keyboardss.trades import trades_keyboard




def trades_menu():

    trades = get_open_trades()
    print(type(trades))
    print(trades)
    trades = trades[-10:]


    total_trades = len(trades)
    if len(trades) == 0:

        text = """
📈 OPEN TRADES

━━━━━━━━━━━━━━━━━━

Şu anda açık işlem yok.

━━━━━━━━━━━━━━━━━━
"""

        keyboard = trades_keyboard(trades)
        print(keyboard)
        return text, keyboard
        print("Trade sayısı:", len(trades))
        print("Keyboard:", keyboard)
        
        return text, back_keyboard()

    text = "📈 OPEN TRADES\n\n━━━━━━━━━━━━━━━━━━\n\n"

    for trade in trades:

        (
        trade_id,
        symbol,
        signal,
        entry,
        tp1,
        tp2,
        tp3,
        stop,
        margin,
        leverage,
        tp1_hit,
        tp2_hit,
        tp3_hit,
        stop_hit,
    ) = trade

        current_price = get_current_price(symbol)

        bar = build_progress(
        signal,
        entry,
        tp3,
        current_price
    )

        emoji = "🟢" if signal == "BUY" else "🔴"

        direction = "LONG" if signal == "BUY" else "SHORT"

        text += (
        f"{emoji} {symbol}    {direction}\n\n"
        f"{bar}\n\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
    )



             
        
    if total_trades > 10:

        text += f"\n📌 Toplam Açık İşlem : {total_trades}"

    return text, trades_keyboard(trades)