from bot_ui.keyboards import back_keyboard
from database.wallet_db import get_wallet


def wallet_menu():

    wallet = get_wallet()

    text = f"""
💰 WALLET

━━━━━━━━━━━━━━━━━━

Balance

💵 {wallet:.2f}$

━━━━━━━━━━━━━━━━━━

📈 Profit

0.00$

📊 ROI

0%

🏆 Win Rate

0%

━━━━━━━━━━━━━━━━━━
"""

    return text, back_keyboard()