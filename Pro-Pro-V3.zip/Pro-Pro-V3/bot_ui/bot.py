from telegram.ext import Application
from config import BOT_TOKEN, CHAT_ID

application = (
    Application.builder()
    .token(BOT_TOKEN)
    .build()
)

bot = application.bot

async def send_signal(message):
    await application.bot.send_message(
        chat_id=CHAT_ID,
        text=message
    )