from services.binance_service import test_connection

import time
START_TIME = time.time()
"""
FollowLine Pro AI V3

Bot Status Service
"""

def format_uptime():

    seconds = int(time.time() - START_TIME)

    hours = seconds // 3600

    minutes = (seconds % 3600) // 60

    secs = seconds % 60

    return f"{hours:02}:{minutes:02}:{secs:02}"

def get_status():

    return {

        "telegram": True,

        "binance": test_connection(),

        "scanner": False,

        "database": True,

        "uptime": format_uptime(),

        "cpu": "-",

        "ram": "-"

    }