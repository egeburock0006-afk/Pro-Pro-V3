from database.schema import create_tables


def init_database():
    create_tables()
    print("🗄️ Veritabanı hazır.")