import os
import requests

from config import BOT_TOKEN, CHAT_ID

# Bu GLOBAL olmalı
DASHBOARD_FILE = "dashboard.msg"


def send_message(text):

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

    requests.post(
        url,
        json={
            "chat_id": CHAT_ID,
            "text": text
        }
    )


def send_dashboard(text, keyboard):
    
    if os.path.exists(DASHBOARD_FILE):

        update_dashboard(text, keyboard)

        return
    
    
    

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

    r = requests.post(
        url,
        json={
            "chat_id": CHAT_ID,
            "text": text,
            "reply_markup": keyboard.to_dict()
        }
    )

    data = r.json()

    if data.get("ok"):

        message_id = data["result"]["message_id"]

        with open(DASHBOARD_FILE, "w") as f:
            f.write(str(message_id))


def update_dashboard(text, keyboard):

    if not os.path.exists(DASHBOARD_FILE):
        send_dashboard(text)
        return

    with open(DASHBOARD_FILE) as f:
        message_id = int(f.read())

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/editMessageText"

    requests.post(
        url,
        json={
            "chat_id": CHAT_ID,
            "message_id": message_id,
            "text": text,
            "reply_markup": keyboard.to_dict()
        }
    )