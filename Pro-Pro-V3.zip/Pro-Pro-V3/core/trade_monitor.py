import time

from helpers.test_formatter import test_dashboard
from services.telegram_service import send_message
from core.test_engine import (
    update_balance,
    add_trade,
    finished,
)












from database.trade_db import (
    get_open_trades,
    mark_tp1,
    mark_tp2,
    mark_tp3,
    mark_stop,
    close_trade,
)

from services.binance_service import get_price
from helpers.pnl_calculator import calculate_profit
from core.test_engine import update_balance, add_trade


def start_trade_monitor():

    print("🛡 Trade Monitor Başlatıldı")

    while True:

        trades = get_open_trades()
        
        print("OPEN TRADES:")
        for t in trades:
            print(t)

        for trade in trades:

            (
                trade_id,
                symbol,
                signal,
                entry,
                tp1,
                tp2,
                tp3,
                stop,
                margin,
                leverage,
                tp1_hit,
                tp2_hit,
                tp3_hit,
                stop_hit,
            ) = trade
            print("SYMBOL =", symbol)
            price = get_price(symbol)

            if price is None:
                continue

            # ==========================
            # BUY
            # ==========================

            if signal == "BUY":

                if not tp1_hit and price >= tp1:

                    print(f"🎯 TP1 HIT -> {symbol}")

                    mark_tp1(trade_id)

                elif tp1_hit and not tp2_hit and price >= tp2:

                    print(f"🚀 TP2 HIT -> {symbol}")

                    mark_tp2(trade_id)

                elif tp2_hit and not tp3_hit and price >= tp3:

                    print(f"🏆 TP3 HIT -> {symbol}")

                    roi, profit = calculate_profit(
                        entry,
                        price,
                        margin,
                        leverage,
                        signal,
                    )

                    wallet = update_balance(profit)

                    add_trade()

                    print(f"Wallet : {wallet:.2f}$")
                    print(f"ROI    : {roi}%")
                    print(f"Profit : {profit}$")

                    mark_tp3(trade_id)

                    close_trade(
                        trade_id,
                        "TP3",
                        roi,
                        profit,
                    )

                elif not stop_hit and price <= stop:

                    print(f"🛑 STOP HIT -> {symbol}")

                    roi, profit = calculate_profit(
                        entry,
                        price,
                        margin,
                        leverage,
                        signal,
                    )

                    wallet = update_balance(profit)

                    add_trade()

                    print(f"Wallet : {wallet:.2f}$")
                    print(f"ROI    : {roi}%")
                    print(f"Profit : {profit}$")

                    mark_stop(trade_id)

                    close_trade(
                        trade_id,
                        "STOP",
                        roi,
                        profit,
                    )

            # ==========================
            # SELL
            # ==========================

            else:

                if not tp1_hit and price <= tp1:

                    print(f"🎯 TP1 HIT -> {symbol}")

                    mark_tp1(trade_id)

                elif tp1_hit and not tp2_hit and price <= tp2:

                    print(f"🚀 TP2 HIT -> {symbol}")

                    mark_tp2(trade_id)

                elif tp2_hit and not tp3_hit and price <= tp3:

                    print(f"🏆 TP3 HIT -> {symbol}")

                    roi, profit = calculate_profit(
                        entry,
                        price,
                        margin,
                        leverage,
                        signal,
                    )

                    wallet = update_balance(profit)
                    add_trade(win=True)
                    send_message(test_dashboard())
                    

                    print(f"Wallet : {wallet:.2f}$")
                    print(f"ROI    : {roi}%")
                    print(f"Profit : {profit}$")

                    mark_tp3(trade_id)

                    close_trade(
                        trade_id,
                        "TP3",
                        roi,
                        profit,
                    )
                    
                    if finished():

                        print("=" * 50)
                        print("🧪 TEST TAMAMLANDI")
                        print(test_dashboard())
                        print("=" * 50)

                        send_message("✅ 100 İşlem Testi Tamamlandı\n\n" + test_dashboard())
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                elif not stop_hit and price >= stop:

                    print(f"🛑 STOP HIT -> {symbol}")

                    roi, profit = calculate_profit(
                        entry,
                        price,
                        margin,
                        leverage,
                        signal,
                    )

                    wallet = update_balance(profit)
                    add_trade(win=False)
                    send_message(test_dashboard())

                    print(f"Wallet : {wallet:.2f}$")
                    print(f"ROI    : {roi}%")
                    print(f"Profit : {profit}$")

                    mark_stop(trade_id)

                    close_trade(
                        trade_id,
                        "STOP",
                        roi,
                        profit,
                    )
                    
                    if finished():

                        print("=" * 50)
                        print("🧪 TEST TAMAMLANDI")
                        print(test_dashboard())
                        print("=" * 50)

                        send_message("✅ 100 İşlem Testi Tamamlandı\n\n" + test_dashboard())

        time.sleep(5)