from services.binance_service import get_current_price
from core.progress_bar import build_progress


def build_trade_card(trade):

    (
        trade_id,
        symbol,
        signal,
        entry,
        tp1,
        tp2,
        tp3,
        stop,
        margin,
        leverage,
        tp1_hit,
        tp2_hit,
        tp3_hit,
        stop_hit,
    ) = trade

    current = get_current_price(symbol)

    bar = build_progress(

        signal,

        entry,

        tp3,

        current

    )

    direction = "LONG" if signal == "BUY" else "SHORT"

    emoji = "🟢" if signal == "BUY" else "🔴"

    text = f"""

{emoji} {symbol}    {direction}

{bar}

"""

    return text