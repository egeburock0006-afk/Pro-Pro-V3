from database.wallet_db import get_wallet
from database.trade_db import get_trades_by_status


def get_wallet_stats():

    wallet = get_wallet()

    closed = get_trades_by_status("CLOSED")

    wins = 0
    losses = 0

    total_profit = 0

    for trade in closed:

        profit = trade[15] if trade[15] else 0

        total_profit += profit

        if profit > 0:
            wins += 1
        elif profit < 0:
            losses += 1

    total = wins + losses

    if total == 0:
        win_rate = 0
    else:
        win_rate = round(wins / total * 100, 2)

    return {

        "wallet": wallet,

        "profit": total_profit,

        "wins": wins,

        "losses": losses,

        "win_rate": win_rate,

        "total": total

    }