def calculate_roi(entry, exit_price, signal, leverage):

    if signal == "BUY":

        roi = ((exit_price - entry) / entry) * leverage * 100

    else:

        roi = ((entry - exit_price) / entry) * leverage * 100

    return round(roi, 2)

def calculate_profit(margin, roi):

    profit = margin * (roi / 100)

    return round(profit, 2)

from database.wallet_db import get_wallet, update_wallet


def update_wallet_profit(profit):

    wallet = get_wallet()

    wallet += profit

    update_wallet(wallet)

    return wallet