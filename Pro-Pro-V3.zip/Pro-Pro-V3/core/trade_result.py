from database.wallet_db import (
    get_wallet,
    update_wallet,
)


def process_trade_result(profit):

    wallet = get_wallet()

    wallet += profit

    update_wallet(wallet)

    return wallet