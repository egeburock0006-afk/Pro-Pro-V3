from core.test_engine import get_stats


def test_dashboard():

    s = get_stats()

    text = f"""
🧪 FOLLOWLINE AI TEST

━━━━━━━━━━━━━━━━━━

💰 Wallet
{s['wallet']:.2f} USDT

📦 Position
{s['position']:.2f} USDT

📊 Trade
{s['trade']} / 100

🏆 Win
{s['wins']}

❌ Loss
{s['losses']}

📈 Win Rate
{s['winrate']} %

━━━━━━━━━━━━━━━━━━
"""

    return text