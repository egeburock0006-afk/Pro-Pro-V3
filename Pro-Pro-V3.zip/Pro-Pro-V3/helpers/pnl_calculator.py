def calculate_profit(entry, exit_price, margin, leverage, signal):

    position = margin * leverage

    if signal == "BUY":

        roi = ((exit_price - entry) / entry) * leverage * 100

    else:

        roi = ((entry - exit_price) / entry) * leverage * 100

    profit = position * (roi / 100)

    return round(roi, 2), round(profit, 2)