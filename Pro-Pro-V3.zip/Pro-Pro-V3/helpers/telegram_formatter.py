from config import INTERVAL, TRADE_MARGIN, LEVERAGE


def format_new_signal(
    symbol,
    signal,
    entry,
    stop,
    tp1,
    tp2,
    tp3,
    ai_score,
    strength,
    atr,
    signal_time
):

    return f"""
🚨 FOLLOWLINE PRO AI V4

🪙 Coin : {symbol}
📢 Signal : {signal}
⏰ Timeframe : {INTERVAL.upper()}
🕒 Signal Time : {signal_time}
━━━━━━━━━━━━━━━━━━
🤖 AI Score : {ai_score}
⭐ Strength : {strength}%
📊 ATR : {atr:.6f}

━━━━━━━━━━━━━━━━━━
💰 Margin : {TRADE_MARGIN}$
⚡ Leverage : {LEVERAGE}X
💼 Position : {TRADE_MARGIN * LEVERAGE}$

━━━━━━━━━━━━━━━━━━
💰 Entry : {entry:.6f}
🛑 Stop : {stop:.6f}
🎯 TP1 : {tp1:.6f}
🎯 TP2 : {tp2:.6f}
🏆 TP3 : {tp3:.6f}

━━━━━━━━━━━━━━━━━━

🤖 FollowLine Pro AI
"""


def format_tp1(
    symbol,
    entry,
    current,
    profit_percent,
    profit_usdt,
    margin,
    leverage
):

    return f"""
🎯 FOLLOWLINE PRO AI

🪙 {symbol}
✅ TP1 HIT
━━━━━━━━━━━━━━━━━━
💰 Entry : {entry:.6f}
📈 Current : {current:.6f}
📊 Profit : %{profit_percent}
💵 Profit : +{profit_usdt}$

━━━━━━━━━━━━━━━━━━
💰 Margin : {margin}$
⚡ Leverage : {leverage}X
💼 Position : {margin * leverage}$

━━━━━━━━━━━━━━━━━━

🤖 Trade Devam Ediyor
"""

def format_tp2(
    symbol,
    entry,
    current,
    profit_percent,
    profit_usdt,
    margin,
    leverage
):

    return f"""
🚀 FOLLOWLINE PRO AI V4

🪙 {symbol}

✅ TP2 HIT
━━━━━━━━━━━━━━━━━━
💰 Entry : {entry:.6f}
📈 Current : {current:.6f}
📊 Profit : %{profit_percent}
💵 Profit : +{profit_usdt}$

━━━━━━━━━━━━━━━━━━
💰 Margin : {margin}$
⚡ Leverage : {leverage}X
💼 Position : {margin*leverage}$

━━━━━━━━━━━━━━━━━━
🔥 Trend Strong

🤖 Trade Continues
"""

def format_tp3(
    symbol,
    entry,
    current,
    profit_percent,
    profit_usdt,
    margin,
    leverage,
    trade_time=None
):

    return f"""
🏆 FOLLOWLINE PRO AI V4

━━━━━━━━━━━━━━━━━━

🪙 {symbol}

💎 MISSION COMPLETE
━━━━━━━━━━━━━━━━━━
💰 Entry : {entry:.6f}
📈 Exit : {current:.6f}

━━━━━━━━━━━━━━━━━━
📊 ROI : %{profit_percent}
💵 Profit : +{profit_usdt}$

━━━━━━━━━━━━━━━━━━
💰 Margin : {margin}$
⚡ Leverage : {leverage}X
💼 Position : {margin*leverage}$

━━━━━━━━━━━━━━━━━━

🏁 Trade Closed Successfully

🤖 FollowLine Pro AI
"""

def format_trade_card(signal):

    return f"""
🧠 FOLLOWLINE PRO AI

━━━━━━━━━━━━━━━━━━

🏆 SELECTED TRADE

{signal['symbol']}

━━━━━━━━━━━━━━━━━━

🤖 AI SCORE
{signal['score']}/100

📈 Signal
{signal['signal']}

💵 Wallet
{signal['wallet']:.2f}$

🎯 Position
{signal['position']:.2f}$

⚡ Leverage
10X

━━━━━━━━━━━━━━━━━━

📍 Entry
{signal['entry']:.6f}

🛑 Stop
{signal['stop']:.6f}

🎯 TP1
{signal['tp1']:.6f}

🚀 TP2
{signal['tp2']:.6f}

👑 TP3
{signal['tp3']:.6f}

━━━━━━━━━━━━━━━━━━

🟢 Status

Trade Selected By AI
"""