import pandas as pd


def mfi(df: pd.DataFrame, period=14):

    data = df.copy()

    # Typical Price
    tp = (
        data["high"] +
        data["low"] +
        data["close"]
    ) / 3

    # Raw Money Flow
    rmf = tp * data["volume"]

    positive = []
    negative = []

    positive.append(0)
    negative.append(0)

    for i in range(1, len(tp)):

        if tp.iloc[i] > tp.iloc[i - 1]:

            positive.append(rmf.iloc[i])
            negative.append(0)

        elif tp.iloc[i] < tp.iloc[i - 1]:

            positive.append(0)
            negative.append(rmf.iloc[i])

        else:

            positive.append(0)
            negative.append(0)

    positive = pd.Series(positive)
    negative = pd.Series(negative)

    pos_sum = positive.rolling(period).sum()
    neg_sum = negative.rolling(period).sum()

    money_ratio = pos_sum / neg_sum.replace(0, 0.00000001)

    mfi = 100 - (100 / (1 + money_ratio))

    return mfi