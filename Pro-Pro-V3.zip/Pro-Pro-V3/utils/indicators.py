"""
FollowLine Pro AI V3

Indicators
"""

import pandas as pd


def ema(series: pd.Series, period: int):
    """
    EMA
    """
    return series.ewm(
        span=period,
        adjust=False
    ).mean()


def atr(df: pd.DataFrame, period=14):
    """
    TradingView ATR
    """

    high_low = df["high"] - df["low"]

    high_close = (
        df["high"] - df["close"].shift(1)
    ).abs()

    low_close = (
        df["low"] - df["close"].shift(1)
    ).abs()

    tr = pd.concat(
        [
            high_low,
            high_close,
            low_close,
        ],
        axis=1,
    ).max(axis=1)

    return tr.rolling(period).mean()