def calculate_ai_score(result, ema200, price, mfi):

    score = 0

    # Trend
    if result["signal"] == "BUY":
        score += 25

    elif result["signal"] == "SELL":
        score += 25

    # EMA
    if price > ema200:
        score += 20

    # MFI

    if 40 <= mfi <= 80:
        score += 20

    # Strength

    strength = float(result["strength"])

    if strength >= 90:
        score += 20

    elif strength >= 75:
        score += 15

    elif strength >= 60:
        score += 10

    # ATR

    atr = result["atr"]

    if atr > 0:
        score += 15

    return score