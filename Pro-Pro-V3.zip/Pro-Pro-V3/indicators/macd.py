import pandas as pd


def macd(close):

    ema12 = close.ewm(span=12, adjust=False).mean()

    ema26 = close.ewm(span=26, adjust=False).mean()

    macd_line = ema12 - ema26

    signal = macd_line.ewm(span=9, adjust=False).mean()

    histogram = macd_line - signal

    return macd_line, signal, histogram